from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

from app.sensitivity import sensitive_matches_from_record
from app.collector_client.command_context import command_error_projection, tool_failure_fact
from app.collector_client.content_events import CONTENT_EVENTS, content_fact
from app.collector_client.content_dedup import stamp_content_identity
from app.collector_client.telemetry_utils import (
    activity_tags as _activity_tags,
    arguments as _arguments,
    change_count as _change_count,
    clean as _clean,
    command_category as _command_category,
    event_type as _event_type,
    exit_code as _exit_code,
    hash_value as _hash,
    object_type as _object_type,
    occurred_at as _occurred_at,
    payload as _payload,
    payload_type as _payload_type,
    ref as _ref,
    safe_key as _safe_key,
    stable_projection as _stable_projection,
    top_type as _top_type,
)
from app.collector_client.tool_execution import command_excerpt, command_text
from app.collector_client.usage_contract import normalized_usage_projection, usage_signal_from_projection

DESTRUCTIVE_OPERATIONS = {"delete", "remove", "rm", "overwrite", "chmod", "permission_change"}


def _record_fact(
    collector_id: str,
    sequence: int,
    source_key: str,
    path: Path,
    line_number: int,
    record: dict,
    *,
    session_titles: dict[str, str] | None = None,
    workspace_resolver: Any | None = None,
) -> dict | None:
    payload = _payload(record)
    event_type = _event_type(record, payload)
    occurred_at = _occurred_at(record)
    refs = _source_refs(collector_id, sequence, source_key, path, line_number, record, session_titles or {}, workspace_resolver)
    event_id = _source_event_id(refs["source_path_hash"], line_number, event_type, occurred_at, record)
    common = {
        "source_event_id": event_id,
        "occurred_at": occurred_at,
        "span": f"codex-session:{_hash(source_key)[:12]}",
        "raw_hash": _hash(_stable_projection(record, include_values=False)),
        "source_refs": refs,
        "source_specific": {
            "event_type": event_type,
            "source_template": "codex.local.sessions.v1",
            "validation_sample": record.get("validation_sample"),
        },
        "upload_raw": True,
    }
    common["raw_content"] = json.dumps(record, ensure_ascii=False, sort_keys=True, default=str)
    if _is_usage(record):
        return _usage_fact(common, record)
    if _is_error(record):
        return _error_fact(common, record)
    if _has_sensitive_marker(record):
        return _sensitive_fact(common, record)
    if change := _file_change_fact(common, record):
        return change
    if risk := _destructive_fact(common, record):
        return risk
    if tool := _tool_fact(common, record):
        return tool
    if _payload_type(record) in CONTENT_EVENTS:
        fact = content_fact(common, record)
        stamp_content_identity(fact, path, record)
        return fact
    return _low_evidence_fact(common, record)

def _error_fact(common: dict, record: dict) -> dict:
    command_projection = command_error_projection(record)
    if command_projection:
        return tool_failure_fact(common, command_projection)
    payload = _payload(record)
    tool = _clean(record.get("tool") or record.get("command") or payload.get("name") or _payload_type(record) or "unknown_tool")
    phase = _clean(record.get("phase") or payload.get("status") or record.get("status") or _top_type(record))
    exit_code = _exit_code(record) or 1
    error_kind = _clean(record.get("error_kind") or payload.get("error") or payload.get("type") or _payload_type(record))
    signature = f"tool_execution_failure:{tool}:{phase}:{exit_code}:{error_kind}"
    return {
        **common,
        "fact_type": "error",
        "category": "tool_execution_failure",
        "quality": "high",
        "severity": "high" if exit_code else "medium",
        "summary": f"工具执行失败：{tool} 在 {phase} 阶段 exit_code={exit_code}。",
        "projection": {"tool": tool, "phase": phase, "exit_code": exit_code, "error_kind": error_kind, "signature": signature},
        "error_signature": {"signature_key": signature, "category": "tool_execution_failure"},
    }

def _usage_fact(common: dict, record: dict) -> dict:
    payload = _payload(record)
    info = payload.get("info") if isinstance(payload.get("info"), dict) else {}
    last_usage = info.get("last_token_usage") if isinstance(info.get("last_token_usage"), dict) else {}
    tags = record.get("activity_tags") or record.get("activity_tag") or _activity_tags(record)
    if isinstance(tags, str):
        activity_tag = _clean(tags)
    elif isinstance(tags, list) and tags:
        activity_tag = _clean(tags[0])
    else:
        activity_tag = "unknown"
    session_id = _ref(record.get("session_id") or record.get("session") or payload.get("turn_id") or "unknown")
    conversation_id = _ref(record.get("conversation_id") or record.get("conversation") or payload.get("turn_id") or "unknown")
    projection = normalized_usage_projection(
        activity_tag=activity_tag,
        input_tokens=last_usage.get("input_tokens"),
        output_tokens=last_usage.get("output_tokens"),
        total_tokens=last_usage.get("total_tokens") or record.get("total_tokens") or record.get("tokens") or record.get("units"),
        cached_input_tokens=last_usage.get("cached_input_tokens"),
        reasoning_output_tokens=last_usage.get("reasoning_output_tokens"),
        model=info.get("model") or record.get("model"),
        provider=info.get("provider") or record.get("provider"),
        cache_observed=bool(last_usage) and "cached_input_tokens" in last_usage,
    )
    projection.update(
        {
            "tag_count": len(tags) if isinstance(tags, list) else 1,
            "model_context_window": int(info.get("model_context_window") or 0),
            "context_total_tokens": _int(last_usage.get("total_tokens")),
        }
    )
    units = int(projection["units"])
    return {
        **common,
        "fact_type": "usage",
        "category": "usage",
        "quality": "high" if activity_tag != "unknown" else "low",
        "severity": "medium" if units >= 100 else "low",
        "summary": f"Agent 会话产生 {units} token 相关用量，活动标签为 {activity_tag}。",
        "projection": projection,
        "usage": usage_signal_from_projection(
            projection,
            scope="session",
            session_id=session_id,
            conversation_id=conversation_id,
            project_ref=common["source_refs"].get("workspace_id") or _ref(record.get("project") or "unknown"),
            account_ref=_ref(record.get("account") or "local"),
        ),
    }

def _effective_usage_units(record: dict, last_usage: dict) -> int:
    explicit = record.get("total_tokens") or record.get("tokens") or record.get("units")
    if explicit is not None:
        return _int(explicit)
    input_tokens = _int(last_usage.get("input_tokens"))
    cached_input_tokens = _int(last_usage.get("cached_input_tokens"))
    output_tokens = _int(last_usage.get("output_tokens"))
    if input_tokens or output_tokens:
        return max(0, input_tokens - cached_input_tokens) + output_tokens
    return _int(last_usage.get("total_tokens"))

def _int(value: object) -> int:
    try:
        return int(value or 0)
    except (TypeError, ValueError):
        return 0

def _file_change_fact(common: dict, record: dict) -> dict | None:
    payload = _payload(record)
    if _payload_type(record) != "patch_apply_end" or not bool(payload.get("success")):
        return None
    changes = payload.get("changes")
    if not isinstance(changes, dict) or not changes:
        return None
    paths = [str(path).replace("\\", "/") for path in changes.keys()]
    additions = sum(_int(value.get("additions")) for value in changes.values() if isinstance(value, dict))
    deletions = sum(_int(value.get("deletions")) for value in changes.values() if isinstance(value, dict))
    top_dirs = _top_directories(paths)
    return {
        **common,
        "fact_type": "risk",
        "category": "file_change",
        "quality": "high",
        "severity": "medium",
        "summary": f"Agent 修改了 {len(paths)} 个工作区文件，新增 {additions} 行，删除 {deletions} 行。",
        "projection": {
            "operation": "file_change",
            "object_type": "workspace_file",
            "changed_paths": paths[:200],
            "file_count": len(paths),
            "additions": additions,
            "deletions": deletions,
            "top_directories": top_dirs,
        },
        "risk": {"risk_type": "file_change", "severity": "medium", "object_type": "workspace_file"},
    }


def _destructive_fact(common: dict, record: dict) -> dict | None:
    payload = _payload(record)
    args = _arguments(payload)
    command = command_text(args)
    command_category = _command_category(command)
    operation = _clean(record.get("operation") or record.get("action") or args.get("operation") or payload.get("name") or record.get("tool") or "")
    path = _clean(record.get("path") or record.get("target") or args.get("path") or args.get("workdir") or "")
    if operation not in DESTRUCTIVE_OPERATIONS and command_category not in {"destructive", "permission_change"} and "delete" not in path:
        return None
    object_type = _object_type(path)
    return {
        **common,
        "fact_type": "risk",
        "category": "destructive_operation",
        "quality": "high",
        "severity": "high",
        "summary": f"检测到破坏性本地操作：{operation or command_category}，对象类型 {object_type}。",
        "projection": {
            "operation": operation or command_category,
            "object_type": object_type,
            "command_excerpt": command_excerpt(command),
            "path_hash": _hash(path)[:16],
            "command_category": command_category,
            "change_count": _change_count(payload),
        },
        "risk": {"risk_type": "destructive_operation", "severity": "high", "object_type": object_type},
    }

def _sensitive_fact(common: dict, record: dict) -> dict:
    matches = _sensitive_matches(record)
    categories = sorted({match["category"] for match in matches})
    object_type = _sensitive_object_type(categories)
    return {
        **common,
        "fact_type": "risk",
        "category": "sensitive_content_exposure",
        "quality": "high",
        "severity": "high",
        "summary": f"Agent 会话暴露高置信敏感内容：{', '.join(categories) if categories else 'unknown'}。",
        "projection": {
            "object_type": object_type,
            "category_count": len(categories),
            "sensitive_categories": categories,
            "sensitive_matches": matches,
            "sensitivity_confidence": "high",
        },
        "risk": {"risk_type": "sensitive_content_exposure", "severity": "high", "object_type": object_type},
    }

def _low_evidence_fact(common: dict, record: dict) -> dict:
    payload = _payload(record)
    return {
        **common,
        "fact_type": "unknown",
        "category": "uncategorized",
        "quality": "low",
        "severity": "low",
        "summary": "Agent 会话出现未归类但来源合法的低证据事件，已保留为低证据命中候选。",
        "projection": {
            "observed_keys": sorted(_safe_key(key) for key in record.keys())[:12],
            "payload_type": _payload_type(record),
            "payload_keys": sorted(_safe_key(key) for key in payload.keys())[:12],
        },
    }

def _tool_fact(common: dict, record: dict) -> dict | None:
    payload = _payload(record)
    payload_type = _payload_type(record)
    if payload_type not in {
        "function_call",
        "custom_tool_call",
        "mcp_tool_call_end",
        "function_call_output",
        "custom_tool_call_output",
        "tool_call",
        "tool_result",
    }:
        return None
    args = _arguments(payload)
    tool_name = _clean(payload.get("name") or payload_type)
    command_category = _command_category(command_text(args))
    exit_code = _exit_code(record)
    if exit_code and exit_code != 0:
        return None
    return {
        **common,
        "fact_type": "tool",
        "category": "tool_call" if "call_output" not in payload_type else "tool_result",
        "quality": "high",
        "severity": "low",
        "summary": f"Agent 调用工具 {tool_name}，类别 {command_category or payload_type}，已提取工具调用摘要。",
        "projection": {
            "tool_name": tool_name,
            "payload_type": payload_type,
            "command_category": command_category,
            "argument_keys": sorted(_safe_key(key) for key in args.keys())[:12],
            "workdir_hash": _hash(str(args.get("workdir", "")))[:16] if args.get("workdir") else None,
            "exit_code": exit_code,
            "raw_content_uploaded": bool(common.get("upload_raw")),
        },
    }


def _top_directories(paths: list[str]) -> list[str]:
    counts: dict[str, int] = {}
    for path in paths:
        directory = "/".join(path.split("/")[:2]) if "/" in path else path
        counts[directory] = counts.get(directory, 0) + 1
    return [path for path, _ in sorted(counts.items(), key=lambda item: (-item[1], item[0]))[:5]]

def _source_refs(
    collector_id: str,
    sequence: int,
    source_key: str,
    path: Path,
    line_number: int,
    record: dict,
    session_titles: dict[str, str] | None = None,
    workspace_resolver: Any | None = None,
) -> dict:
    payload = _payload(record)
    session_ref = record.get("session_id") or record.get("session") or payload.get("id") or path.stem
    conversation_ref = (
        record.get("conversation_id")
        or record.get("conversation")
        or payload.get("turn_id")
        or record.get("session_id")
        or record.get("session")
        or path.stem
    )
    refs = {
        "collector_id": collector_id,
        "sequence": sequence,
        "source_key": source_key,
        "source_path_hash": _hash(path.as_posix())[:16],
        "line": line_number,
        "conversation_ref": _ref(conversation_ref),
        "session_ref": _ref(session_ref),
    }
    if title := _session_title(session_titles or {}, record, payload, path, session_ref):
        refs["session_title"] = title
    if workspace_resolver is not None:
        refs.update({key: value for key, value in workspace_resolver.resolve(path, record).items() if value})
    return refs

def _session_title(session_titles: dict[str, str], record: dict, payload: dict, path: Path, session_ref: object) -> str:
    for candidate in _session_title_candidates(record, payload, path, session_ref):
        title = session_titles.get(candidate)
        if title:
            return title
    return ""

def _session_title_candidates(record: dict, payload: dict, path: Path, session_ref: object) -> list[str]:
    values = [record.get("session_id"), record.get("session"), payload.get("id"), session_ref, path.stem]
    match = re.search(r"([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})", path.stem, re.IGNORECASE)
    if match:
        values.append(match.group(1))
    result = []
    for value in values:
        text = str(value or "").strip()
        if text and text not in result:
            result.append(text)
    return result

def _source_event_id(path_hash: str, line_number: int, event_type: str, occurred_at: str, record: dict) -> str:
    native_id = record.get("id") or record.get("event_id") or record.get("call_id")
    if native_id:
        return f"codex-{_hash(path_hash, str(native_id), line_number, event_type)[:32]}"
    content_hash = _hash(_stable_projection(record, include_values=True))
    return f"codex-{_hash(path_hash, line_number, event_type, occurred_at, content_hash)[:32]}"

def _is_error(record: dict) -> bool:
    payload = _payload(record)
    if _payload_type(record) in {"function_call_output", "custom_tool_call_output"}:
        exit_code = _exit_code(record)
        if exit_code is not None:
            return exit_code != 0
    status = str(record.get("status") or record.get("level") or payload.get("status") or "").lower()
    if status in {"error", "failed", "failure"}:
        return True
    if _payload_type(record) == "patch_apply_end" and payload.get("success") is False:
        return True
    try:
        return int(record.get("exit_code") or 0) != 0
    except (TypeError, ValueError):
        return False

def _is_usage(record: dict) -> bool:
    if any(key in record for key in ("total_tokens", "tokens", "units", "activity_tag", "activity_tags")):
        return True
    payload = _payload(record)
    return _payload_type(record) == "token_count" and isinstance(payload.get("info"), dict)

def _has_sensitive_marker(record: dict) -> bool:
    return bool(_sensitive_matches(record))

def _sensitive_matches(record: dict) -> list[dict[str, str]]:
    payload = _payload(record)
    args = _arguments(payload)
    return sensitive_matches_from_record(record, payload, args)

def _sensitive_object_type(categories: list[str]) -> str:
    if any(category in {"token", "secret", "credential", "cookie"} for category in categories):
        return "credential"
    if "auth" in categories:
        return "auth"
    return "sensitive_reference"
