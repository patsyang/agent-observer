"""Packaged Windows collector client."""
